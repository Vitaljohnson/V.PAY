export default function Payment() {
  return (
    <div className='p-6'>
      <h2 className='text-xl font-bold text-green-600 mb-4'>Make a Payment</h2>
      <form className='grid gap-4'>
        <input type='text' placeholder='Card Number' className='border p-2' />
        <input type='text' placeholder='Expiry Date' className='border p-2' />
        <input type='text' placeholder='CVV' className='border p-2' />
        <input type='number' placeholder='Amount' className='border p-2' />
        <button className='bg-green-600 text-white py-2'>Pay Now</button>
      </form>
    </div>
  );
}