export default function Login() {
  return (
    <div className='p-6'>
      <h2 className='text-xl font-bold text-green-600 mb-4'>Login</h2>
      <form className='grid gap-4'>
        <input type='email' placeholder='Email' className='border p-2' />
        <input type='password' placeholder='Password' className='border p-2' />
        <button className='bg-black text-white py-2'>Login</button>
      </form>
    </div>
  );
}