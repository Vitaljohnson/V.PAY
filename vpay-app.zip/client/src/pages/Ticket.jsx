export default function Ticket() {
  return (
    <div className='p-6'>
      <h2 className='text-xl font-bold text-green-600 mb-4'>Your Ticket</h2>
      <img src='/ticket-sample.png' alt='Your Ticket' className='border' />
    </div>
  );
}