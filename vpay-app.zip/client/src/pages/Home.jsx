export default function Home() {
  return (
    <div className='text-center text-green-700 p-10'>
      <h1 className='text-3xl font-bold'>Welcome to V.Pay</h1>
    </div>
  );
}