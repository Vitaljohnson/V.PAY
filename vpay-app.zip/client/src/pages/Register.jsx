export default function Register() {
  return (
    <div className='p-6'>
      <h2 className='text-xl font-bold text-green-600 mb-4'>Register</h2>
      <form className='grid gap-4'>
        <input type='email' placeholder='Email or Phone' className='border p-2' />
        <input type='password' placeholder='Password' className='border p-2' />
        <button className='bg-black text-white py-2'>Register</button>
      </form>
    </div>
  );
}