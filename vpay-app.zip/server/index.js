const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/payment', (req, res) => {
  // simulate payment to 2667044247 Zenith Bank
  console.log('Payment received:', req.body);
  res.json({ status: 'success', message: 'Paid Successfully' });
});

app.listen(5000, () => console.log('Server running on port 5000'));